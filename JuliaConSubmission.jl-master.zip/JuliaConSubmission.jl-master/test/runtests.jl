using JuliaConSubmission
using Test

@testset "JuliaConSubmission.jl" begin
    # Write your own tests here.
end
